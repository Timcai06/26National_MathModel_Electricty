"""Compile the portable LaTeX draft and copy only its PDF into the handoff."""
from pathlib import Path
import subprocess,shutil
R=Path(__file__).resolve().parents[2]
build=R/'tmp/paper_v1_build'; build.mkdir(parents=True,exist_ok=True)
cmd=['rtk','proxy','/Library/TeX/texbin/latexmk','-norc','-xelatex','-interaction=nonstopmode','-halt-on-error',f'-outdir={build}','main.tex']
subprocess.run(cmd,cwd=R/'deliverables/draft_v1/latex',check=True)
log=(build/'main.log').read_text()
issues=[line for line in log.splitlines() if any(x in line for x in ['Overfull','Missing character','undefined references','undefined citations'])]
if issues: raise RuntimeError('Resolve TeX issues before publishing PDF: '+str(issues))
shutil.copy2(build/'main.pdf',R/'deliverables/draft_v1/pdf/C_microgrid_draft_v1.pdf')
print('PDF published to deliverables/draft_v1/pdf/C_microgrid_draft_v1.pdf')
