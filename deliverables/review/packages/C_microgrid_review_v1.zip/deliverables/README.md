# 论文与交付统一入口

当前版本：**第一版研究稿 V1，2026-09-11；不是最终提交包。**

## 先看这些文件

- [整套V1审阅包 ZIP](C_microgrid_review_v1.zip)：包含源码、图表、PDF及明确标注的旧Excel，非正式提交包。
- [第一版论文 PDF](draft_v1/pdf/C_microgrid_draft_v1.pdf)
- [LaTeX 主文件](draft_v1/latex/main.tex)：源文件与自动生成的表格一起保存。
- [候选图表目录](candidate_figures/v1/)：6组数据图，每组含矢量 PDF 与 PNG；系统结构和时序图使用正文中的 TikZ 源码。
- [候选图表来源及哈希](candidate_figures/v1/manifest.json)
- [四个指定日紧急区间 CSV](candidate_figures/v1/selected_emergency_intervals.csv)：Q2 B2及Q3裕量固定的内部物理区间。
- [旧五份 Excel](legacy_excel/)：仅供核对原模板与旧结果，**不与本稿构成同版本提交**。
- [证据摘录](review/)：当前Q2/Q3结果、独立验收、比较表及清理日志。

## 目录职责

| 目录 | 内容 | 当前状态 |
| --- | --- | --- |
| `draft_v1/latex/` | 论文主文件、生成表格 | 已可编译的V1 |
| `draft_v1/pdf/` | 供阅读的PDF | 草稿，有明确限制说明 |
| `candidate_figures/v1/` | 图表源数据索引、矢量图、预览图 | 候选，未作为最终批准图 |
| `legacy_excel/` | result1、2、3、4-2、4-3旧候选副本 | 未重算，未修正模板映射 |
| `review/` | 验收证据与版本整理记录 | 供内部复核 |
| `final_submission/` | 以后只放最终论文与五份正式Excel | 当前不放任何候选结果 |

`analysis/` 是可追溯的实验档案，`outputs/` 是旧模板写入与回读证据；二者保留原路径，避免移动后破坏源文件哈希、脚本及文档链接。无需再从这些目录寻找当前论文入口。数据、源码、测试和运行环境均保留。

## 本稿选用结果

Q1采用真实代表日优化；Q2采用B2（15,137,987.06元）；Q3采用裕量零点固定（15,129,676.16元）作为简单主候选，同时报告门控较低的实测费用15,122,320.83元。年度范围为2025-02-01至12-31，共334天。应急费已经包含5倍系数。

Q4只写迁移模型及明确标注的旧版历史数字；没有伪造严格迁移结果。当前右端采样物理区间与官方Excel表头存在10分钟差异，因此尚未用本稿新策略重导出Excel。文献库没有整库引入，正式综述与来源核验待补。

## 从项目根目录重建

```sh
rtk proxy .venv/bin/python scripts/paper/build_assets.py
rtk proxy .venv/bin/python scripts/paper/build_pdf.py
```

编译依赖现有 XeLaTeX、latexmk 和项目 Matplotlib、NumPy。图表/表格构建不运行优化，不改已有数值。编译中间产物进入 `tmp/paper_v1_build/`，不混入交付目录。根目录的生成脚本为源文件，不能当临时文件删除。

下一版封版前：统一时间采样和日界映射；补第四问严格迁移；同策略生成五份Excel；核验引用和竞赛格式；完成论文、表格与账本一致性验收。这里的 `final_submission/` 仅用于已通过上述检查的正式产物。
